# ABDULMALIK RACING

This is a phone-friendly starter project for turning the ABDULMALIK RACING web game into an Android app with Capacitor.

## Current contents
- `www/index.html` — playable racing prototype
- `package.json` — Capacitor dependencies
- `capacitor.config.ts` — Android app name and package ID
- `.github/workflows/android.yml` — cloud build workflow for a test APK

## Important
The workflow creates a **debug APK for testing**. A Google Play release needs a properly signed **release AAB** and the current Play Console requirements must be followed.

Next stage:
1. Put this project in a GitHub repository.
2. Run the Android workflow from GitHub Actions.
3. Test the APK on the phone.
4. Prepare release signing and an AAB for Play Console.
