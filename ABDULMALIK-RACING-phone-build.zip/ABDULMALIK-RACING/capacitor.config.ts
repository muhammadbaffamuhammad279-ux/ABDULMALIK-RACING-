import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.abdulmalik.racing',
  appName: 'ABDULMALIK RACING',
  webDir: 'www'
};

export default config;
